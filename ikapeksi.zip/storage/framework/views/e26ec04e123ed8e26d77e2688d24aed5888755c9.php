<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => 'Administrator'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="wrapper" id="wrapper">

        <?php $__env->startPush('style'); ?>
            <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
        <?php $__env->stopPush(); ?>

        <?php if (isset($component)) { $__componentOriginal548fe59e8e4d424287091d005d0da84f5245ee0c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal548fe59e8e4d424287091d005d0da84f5245ee0c)): ?>
<?php $component = $__componentOriginal548fe59e8e4d424287091d005d0da84f5245ee0c; ?>
<?php unset($__componentOriginal548fe59e8e4d424287091d005d0da84f5245ee0c); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal3521a1fa11002ac0abd148abefb6a68539feeea0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminSidebar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3521a1fa11002ac0abd148abefb6a68539feeea0)): ?>
<?php $component = $__componentOriginal3521a1fa11002ac0abd148abefb6a68539feeea0; ?>
<?php unset($__componentOriginal3521a1fa11002ac0abd148abefb6a68539feeea0); ?>
<?php endif; ?>

        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Laporan</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('administrator')); ?>">Home</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo e(url('administrator/laporan')); ?>">Laporan</a></li>
                                <li class="breadcrumb-item active">Files</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
      
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="bg-white shadow-sm rounded">
                                <div class="p-3 border-bottom">
                                    <div class="row align-items-center justify-content-between">
                                        <div class="col-md-6">
                                            <h5 class="mb-0">Daftar Laporan</h5>
                                            <small>Daftar Files Laporan Anda</small>
                                        </div>
                                        <div class="col-md-6 text-end">
                                            <a href="javascript:void(0)" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#add">Tambah</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="p-3">
                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger" role="alert">
                                            <strong>Gagal!</strong>
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($item); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <table class="table table-bordered" id="table">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>NAMA</th>
                                                <th>ACTION</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </div>

        <?php if (isset($component)) { $__componentOriginal0af80189ee9d18748f45cc907e25d7b5a0980777 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0af80189ee9d18748f45cc907e25d7b5a0980777)): ?>
<?php $component = $__componentOriginal0af80189ee9d18748f45cc907e25d7b5a0980777; ?>
<?php unset($__componentOriginal0af80189ee9d18748f45cc907e25d7b5a0980777); ?>
<?php endif; ?>

        <?php $__env->startPush('script'); ?>
            <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
            <script>
                $(document).ready( function () {
                    $('#table').DataTable({
                        processing: true,
                        serverSide: true,
                        ajax: `<?= url('administrator/api/laporan/' . Request::segment(4)) ?>`,
                        columns: [
                            { data: 'DT_RowIndex', name: 'id' },
                            { data: 'name', name: 'name' },
                            { data: 'action', name: 'action' },
                        ],
                        "initComplete":function( settings, json){
                            $('.edit').on('click', function(data){

                                const dataID = $(this).data('id');
                                let action = `<?= url('administrator/laporan/edit/${dataID}') ?>`;

                                $('.edit-name').val($(this).data('name'))
                                $('#form').attr('action', action);
                                $('#edit').modal('show');
                            });
                        }
                    });

                    
                });
            </script>
        <?php $__env->stopPush(); ?>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Project\Laravel\ikapeksi\resources\views/administrator/report/files.blade.php ENDPATH**/ ?>