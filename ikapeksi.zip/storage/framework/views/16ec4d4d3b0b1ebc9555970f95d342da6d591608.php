<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => 'Administrator'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="wrapper" id="wrapper">

        <?php $__env->startPush('style'); ?>
        <?php $__env->stopPush(); ?>

        <?php if (isset($component)) { $__componentOriginal548fe59e8e4d424287091d005d0da84f5245ee0c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal548fe59e8e4d424287091d005d0da84f5245ee0c)): ?>
<?php $component = $__componentOriginal548fe59e8e4d424287091d005d0da84f5245ee0c; ?>
<?php unset($__componentOriginal548fe59e8e4d424287091d005d0da84f5245ee0c); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal3521a1fa11002ac0abd148abefb6a68539feeea0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminSidebar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3521a1fa11002ac0abd148abefb6a68539feeea0)): ?>
<?php $component = $__componentOriginal3521a1fa11002ac0abd148abefb6a68539feeea0; ?>
<?php unset($__componentOriginal3521a1fa11002ac0abd148abefb6a68539feeea0); ?>
<?php endif; ?>

        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Berita</h1>
                            <p>Tulis Berita Baru</p>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('administrator')); ?>">Home</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo e(url('administrator/news')); ?>">Berita</a></li>
                                <li class="breadcrumb-item active">Add</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
      
            <form method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <section class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        <strong>Gagal! </strong>
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($item); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul> 
                                    </div>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <div class="row align-items-center">
                                            <div class="col-md-10">
                                                <input type="text" placeholder="Judul" name="title" id="title" class="form-control"/>
                                            </div>
                                            <div class="col-md-2">
                                                <button type="submit" class="btn btn-primary w-100">Simpan</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-9 mb-3">
                                        <textarea name="text" class="editor"></textarea>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="bg-white shadow-sm border mb-3">
                                            <div class="widget-header p-3 border-bottom">
                                                <strong>Thumbnail</strong>
                                            </div>
                                            <div class="p-3">
                                                <div class="form-group mb-0">
                                                    <input type="file" name="thumbnail" id="thumbnail" class="form-control"/>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bg-white shadow-sm border mb-3">
                                            <div class="widget-header p-3 border-bottom">
                                                <strong>Mulai</strong>
                                            </div>
                                            <div class="p-3">
                                                <div class="form-group mb-0">
                                                    <input type="date" name="start_at" id="start_at" class="form-control"/>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bg-white shadow-sm border mb-3">
                                            <div class="widget-header p-3 border-bottom">
                                                <strong>Selesai</strong>
                                            </div>
                                            <div class="p-3">
                                                <div class="form-group mb-0">
                                                    <input type="date" name="end_at" id="end_at" class="form-control"/>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bg-white shadow-sm border mb-3">
                                            <div class="widget-header p-3 border-bottom">
                                                <strong>Lokasi</strong>
                                            </div>
                                            <div class="p-3">
                                                <div class="form-group mb-0">
                                                    <input type="text" name="location" placeholder="Enter location event" id="location" class="form-control"/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </form>

        </div>

        <?php if (isset($component)) { $__componentOriginal0af80189ee9d18748f45cc907e25d7b5a0980777 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0af80189ee9d18748f45cc907e25d7b5a0980777)): ?>
<?php $component = $__componentOriginal0af80189ee9d18748f45cc907e25d7b5a0980777; ?>
<?php unset($__componentOriginal0af80189ee9d18748f45cc907e25d7b5a0980777); ?>
<?php endif; ?>

        <?php $__env->startPush('script'); ?>
            <script src="<?php echo e(asset('plugin/ckeditor/build/ckeditor.js')); ?>"></script>
            <script src="<?php echo e(asset('plugin/ckfinder/ckfinder.js')); ?>"></script>
            <script>
                $(document).ready( function () {
                    ClassicEditor
                    .create( document.querySelector( '.editor' ), {
                        licenseKey: '',
                        ckfinder: {
                            uploadUrl: '<?php echo asset("plugin/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json"); ?>',
                            options: {
                                resourceType: 'Images'
                            }
                        },
                    })
                    .then( editor => {
                        window.editor = editor;
                    })
                    .catch( error => {
                        console.error( 'Oops, something went wrong!' );
                        console.error( 'Please, report the following error on https://github.com/ckeditor/ckeditor5/issues with the build id and the error stack trace:' );
                        console.warn( 'Build id: nyny6d5pm98w-f9z6zbpoy7ms' );
                        console.error( error );
                    });
                });
            </script>
        <?php $__env->stopPush(); ?>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Project\Laravel\ikapeksi\resources\views/administrator/event/add.blade.php ENDPATH**/ ?>