<footer class="main-footer">
    <strong>Copyright &copy; 2022 Ikatan Pengusaha Kenshuusei Indonesia</strong> All rights reserved.
</footer>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('adminlte/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminlte/plugins/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminlte/js/adminlte.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminlte/js/pages/dashboard.js')); ?>"></script>  
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\Project\Laravel\ikapeksi\resources\views/administrator/layout/footer.blade.php ENDPATH**/ ?>