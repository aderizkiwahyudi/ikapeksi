<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => 'Event'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php if (isset($component)) { $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804)): ?>
<?php $component = $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804; ?>
<?php unset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804); ?>
<?php endif; ?>
    
    <div class="breadcrumb-container">
        <div class="container">
            <nav class="breadcrumb">
                <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">Home</a>
                <span class="breadcrumb-item active">Event</span>
            </nav>
        </div>
    </div>

    <div class="container">
        <div class="news-container my-5">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <div class="widget categories event">
                        <ul>
                            <li class="active"><a href="<?php echo e(url('event')); ?>">Event</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-9 mb-3">
                    <div class="news-headline mb-3">
                        <h5>Event</h5>
                        <small>Daftar Event</small>
                    </div>
                    <div class="row event">
                        <?php $__empty_1 = true; $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-6 mb-3">
                                <div class="event-item">
                                    <?php if($item->start_at < date('Y-m-d')): ?>
                                        <div class="event-end">Event Selesai</div>
                                    <?php endif; ?>
                                    <div class="thumbnail-event" style="background-image: url('https://www.kadin.id/public/images/editor-c2ca6d0224b1c4010d6c4ba253e454a33bed88a0.jpeg')"></div>
                                    <div class="event-item-body">
                                        <div class="event-item-title">
                                            <h4><?php echo e(substr($item->title, 0, 100)); ?><?= strlen($item->title) > 100 ? "..." : "" ?></h4>
                                        </div>
                                        <div class="date">
                                            <h5><i class="bi bi-calendar"></i> <?php echo e(Helpers::hari($item->start_at)); ?>, <?php echo e(Helpers::tanggal($item->start_at)); ?></h5>
                                            <h5><i class="bi bi-geo-alt"></i> <?php echo e($item->location); ?></h5>
                                        </div>
                                    </div>
                                    <a href="<?php echo e(url('event/' . $item->slug)); ?>" class="btn btn-registration btn-event">Daftar Sekarang</a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>Belum ada event</p>
                        <?php endif; ?>
                    </div>
                    <div class="py-3">
                        <?php echo e($event->links()); ?>

                        <?php if(count($total) > $jumlahPerPage): ?>
                            <div class="my-2">
                                <small>Halaman ke <?php echo e($event->currentPage()); ?> dari <?php echo e($lastPage); ?> Halaman</small>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69)): ?>
<?php $component = $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69; ?>
<?php unset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69); ?>
<?php endif; ?>
    
    <?php $__env->startPush('script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script>
            $(document).ready(function(){
                
            });
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Project\Laravel\ikapeksi\resources\views/event.blade.php ENDPATH**/ ?>