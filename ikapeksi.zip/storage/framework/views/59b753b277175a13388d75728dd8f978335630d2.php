<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php if (isset($component)) { $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804)): ?>
<?php $component = $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804; ?>
<?php unset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804); ?>
<?php endif; ?>
    
    <div class="breadcrumb-container">
        <div class="container">
            <nav class="breadcrumb">
                <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">Home</a>
                <span class="breadcrumb-item active">Berita</span>
            </nav>
        </div>
    </div>

    <div class="container">
        <div class="news-container my-5">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <?php if (isset($component)) { $__componentOriginal5656a25c0f87b6e6d4ce4d5a6308e0c08a8b3789 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppWidgetCategories::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-widget-categories'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppWidgetCategories::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5656a25c0f87b6e6d4ce4d5a6308e0c08a8b3789)): ?>
<?php $component = $__componentOriginal5656a25c0f87b6e6d4ce4d5a6308e0c08a8b3789; ?>
<?php unset($__componentOriginal5656a25c0f87b6e6d4ce4d5a6308e0c08a8b3789); ?>
<?php endif; ?>
                </div>
                <div class="col-md-9 mb-3">
                    <div class="news-headline">
                        <h5>Berita</h5>
                        <small>Daftar Berita Utama</small>
                    </div>
                    <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row items mt-5">
                            <div class="col-md-3">
                                <img src="<?php echo e($item->thumbnail); ?>" alt="<?php echo e($item->title); ?>" width="100%">
                            </div>
                            <div class="col-md-9">
                                <h4><a href="<?php echo e(url('news/' . $item->slug)); ?>"><?php echo e($item->title); ?></a></h4>
                                <div class="date">
                                    <i class="bi bi-clock"></i> <?php echo e(Helpers::hari($item->created_at)); ?>, <?php echo e(Helpers::tanggal($item->created_at)); ?>

                                </div>
                                <p>
                                    <?= htmlspecialchars(strip_tags(substr($item->text, 0, 150))) ?> ...
                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>Tidak ada berita</p>
                    <?php endif; ?>
                    <div class="py-3">
                        <?php echo e($news->links()); ?>

                        <?php if(count($total) > $jumlahPerPage): ?>
                            <div class="my-2">
                                <small>Halaman ke <?php echo e($news->currentPage()); ?> dari <?php echo e($lastPage); ?> Halaman</small>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69)): ?>
<?php $component = $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69; ?>
<?php unset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69); ?>
<?php endif; ?>
    
    <?php $__env->startPush('script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script>
            $(document).ready(function(){
                
            });
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Project\Laravel\ikapeksi\resources\views/news.blade.php ENDPATH**/ ?>