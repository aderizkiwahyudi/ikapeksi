<div class="background-navigation"></div>
<header>
    <div class="header container">
        <div class="d-flex align-items-center justify-content-between">
            <div class="logo">
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e($web->logo); ?>" alt="<?php echo e($web->name); ?>" width="100px"/></a>
            </div>
            <div class="bars">
                <a href="javascript:void(0)"><i class="bi bi-list"></i></a>
            </div>
            <div class="navigation">
                <ul class="nav">
                    <li>
                        <a href="<?php echo e(url('/')); ?>">HOME</a>
                    </li>
                    <li>
                        <a href="#">TENTANG KAMI</a>
                        <ul class="submenus">
                            <li>
                                <a href="<?php echo e(url('/page/sejarah')); ?>">Sejarah</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/page/uu-ad-art')); ?>">UU/AD/ART</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/page/peraturan-dan-pedoman-organisasi')); ?>">Peraturan dan Pedomam Organisasi</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/page/lambang')); ?>">Lambang</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/page/mars-hymne')); ?>">Mars & Hymne</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/page/struktur-organisasi')); ?>">Struktur Organisasi</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/page/visi-misi')); ?>">Visi dan Misi</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">KEANGGOTAAN</a>
                        <ul class="submenus">
                            <li>
                                <a href="<?php echo e(url('/page/persyaratan-prosedur')); ?>">Persyaratan dan Prosedur</a>
                            </li>
                            <li>
                                <a href="<?php echo e($web->pendaftaran); ?>">Pendaftaran Online</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/page/asosiasi-himoynan')); ?>">Asosiasi/Himoynan</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/page/asosiasi-terakreditasi')); ?>">Asosiasi Terakreditasi</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="<?php echo e(url('event')); ?>">EVENT</a>
                    </li>
                    <li>
                        <a href="#">PUBLIKASI</a>
                        <ul class="submenus">
                            <li>
                                <a href="<?php echo e(url('categories/berita-pusat')); ?>">Berita Pusat</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('categories/berita-daerah')); ?>">Berita Daerah</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('galeri/all')); ?>">Galeri</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('laporan')); ?>">Laporan</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0)">PROGRAM</a>
                        <?php if(count($program) > 0): ?>
                            <ul class="submenus">
                                <?php $__currentLoopData = $program; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e($item->url); ?>"><?php echo e($item->name); ?></a>
                                    </li> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
            <div class="registration">
                <div class="text-end">
                    <a href="<?php echo e($web->pendaftaran); ?>" class="btn btn-registration">Pendaftaran Online</a>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH C:\xampp\htdocs\Project\Laravel\ikapeksi\resources\views/layout/header.blade.php ENDPATH**/ ?>