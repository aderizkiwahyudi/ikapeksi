<div class="widget categories">
    <ul>
        <li class="<?php echo e(Request::segment(2) ?? 'active'); ?>"><a href="<?php echo e(url('news')); ?>">Berita Utama</a></li>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="<?php echo e(Request::segment(2) == $item->slug ? 'active' : ''); ?>"><a href="<?php echo e(url('categories/' . $item->slug)); ?>"><?php echo e($item->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li class="<?php echo e(Request::segment(1) == 'galeri' ? 'active' : ''); ?>"><a href="<?php echo e(url('galeri/all')); ?>">Galeri</a></li>
    </ul>
</div><?php /**PATH C:\xampp\htdocs\Project\Laravel\ikapeksi\resources\views/widget/categories.blade.php ENDPATH**/ ?>