<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => ''.e($event->title).''] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startPush('meta'); ?>
            <meta property="og:title" content="<?php echo e($event->title); ?>">
            <meta property="og:type" content="article"/>
            <meta property="og:image" content="<?php echo e($event->thumbnail); ?>">
            <meta property="og:url" content="<?php echo e(url('news/' . $event->slug)); ?>">
            <meta name="twitter:card" content="summary_large_image">
    <?php $__env->stopPush(); ?>
    
    <?php if (isset($component)) { $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804)): ?>
<?php $component = $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804; ?>
<?php unset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804); ?>
<?php endif; ?>
    
    <div class="breadcrumb-container">
        <div class="container">
            <nav class="breadcrumb">
                <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">Home</a>
                <a class="breadcrumb-item" href="<?php echo e(url('/event')); ?>">Event</a>
                <span class="breadcrumb-item active"><?php echo e($event->title); ?></span>
            </nav>
        </div>
    </div>

    <div class="container">
        <div class="news-container my-5">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <div class="widget categories event">
                        <div class="p-4 shadow-sm rounded">
                            <div class="event-detail-headline">Informasi Event</div>
                            <div class="event-detail-body mt-4">
                                <div class="mb-4">
                                    <p class="mb-0"><strong>Mulai</strong></p>
                                    <p><?php echo e(Helpers::hari($event->start_at)); ?>, <?php echo e(Helpers::tanggal($event->start_at)); ?></p>
                                </div>
                                <div class="mb-4">
                                    <p class="mb-0"><strong>Berakhir</strong></p>
                                    <p><?php echo e(Helpers::hari($event->end_at)); ?>, <?php echo e(Helpers::tanggal($event->end_at)); ?></p>
                                </div>
                                <div class="mb-4">
                                    <p class="mb-0"><strong>Lokasi</strong></p>
                                    <p><?php echo e($event->location); ?></p>
                                </div>
                                <a href="javascript:void(0)" class="btn btn-registration btn-event w-100" data-bs-toggle="modal" data-bs-target="#registrationEvent">Daftar Sekarang</a>
                            </div>
                            
                            <?php if($event->start_at > date('Y-m-d')): ?>
                                <!-- Modal -->
                                <div class="modal fade" id="registrationEvent" tabindex="-1" role="dialog" aria-labelledby="registrationEvent" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <form method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($event->id); ?>"/>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Form Pendaftaran</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="mb-3 form-group">
                                                        <label for="name" class="form-label">Nama Lengkap</label>
                                                        <input type="text" name="name" id="" class="form-control" placeholder="" aria-describedby="name">
                                                    </div>
                                                    <div class="mb-3 form-group">
                                                        <label for="email" class="form-label">Email</label>
                                                        <input type="email" name="email" id="" class="form-control" placeholder="" aria-describedby="email">
                                                    </div>
                                                    <div class="mb-3 form-group">
                                                        <label for="name" class="form-label">Perusahaan</label>
                                                        <input type="text" name="company" id="" class="form-control" placeholder="" aria-describedby="instansi">
                                                    </div>
                                                    <div id="alert"></div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-registration btn-event w-100" id="registration">Daftar Sekarang</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?> 
                                <!-- Modal -->
                                <div class="modal fade" id="registrationEvent" tabindex="-1" role="dialog" aria-labelledby="registrationEvent" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <form method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($event->id); ?>"/>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Form Pendaftaran</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="alert alert-warning" role="alert">
                                                        <strong>Event sudah berakhir</strong>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-9 mb-3">
                    <div class="news-headline pb-3">
                        <h4><?php echo e($event->title); ?></h3>
                    </div>
                    <img src="<?php echo e($event->thumbnail); ?>" alt="<?php echo e($event->title); ?>" width="100%"/>
                    <div class="news-text pt-3">
                        <?php echo $event->text; ?>

                    </div>
                    <div class="share pt-3">
                        <div class="d-flex align-items-center" id="share-sossial-buttons">
                            <div class="me-2">
                                Share
                            </div>
                            <!-- Untuk Email -->
                            <a class="btn btn-share-mail" href="mailto:?Subject=<?php echo e($event->title); ?>&Body=<?php echo $event->text; ?>">
                                <i class="bi bi-envelope-fill"></i>
                            </a>
                            <!-- Untuk Facebook -->
                            <a class="btn btn-share-facebook"  href="http://www.facebook.com/sharer.php?u=<?php echo e(url('event/' . $event->slug)); ?>" target="_blank">
                                <i class="bi bi-facebook"></i>
                            </a>
                            <!-- Untuk Google+ -->
                            <a class="btn btn-share-gplus" href="https://plus.google.com/share?url=<?php echo e(url('event/' . $event->slug)); ?>" target="_blank">
                                <i class="bi bi-google"></i>
                            </a>
                            <!-- Untuk Twitter -->
                            <a class="btn btn-share-twitter" href="https://twitter.com/share?url=<?php echo e(url('event/' . $event->slug)); ?>&text=<?php echo e($event->title); ?>" target="_blank">
                                <i class="bi bi-twitter"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69)): ?>
<?php $component = $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69; ?>
<?php unset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69); ?>
<?php endif; ?>
    
    <?php $__env->startPush('script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script>
            $(document).ready(function(){
                $('#registration').on('click', function(){
                    let el = $(this);
                    el.attr('disabled', true).html('Loading');

                    let data = $('form').serializeArray();

                    $.ajax({
                        url: "<?php echo e(route('eventRegistration')); ?>",
                        type: 'POST',
                        data: data,
                    }).done(function(response) {
                        response = JSON.parse(response);
                        el.removeAttr('disabled').html("Daftar Sekarang");

                        if(response.success){
                            $('#alert').html(`
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    ${response.message}
                                </div>
                            `);
                        }else{
                            $('#alert').html(`
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    ${response.message}
                                </div>
                            `);
                        }
                    });
                });
            });
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Project\Laravel\ikapeksi\resources\views/eventDetail.blade.php ENDPATH**/ ?>