<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => ''.e($gallery->title).''] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startPush('meta'); ?>
            <meta property="og:title" content="<?php echo e($gallery->title); ?>">
            <meta property="og:type" content="article"/>
            <meta property="og:image" content="<?php echo e($gallery->thumbnail); ?>">
            <meta property="og:url" content="<?php echo e(url('gallery/view/' . $gallery->slug)); ?>">
            <meta name="twitter:card" content="summary_large_image">
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('style'); ?>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/viewerjs/1.10.4/viewer.min.css" integrity="sha512-OgbWuZ8OyVQxlWHea0T9Bdy1oDhs380WxLMaLZbuitQ/mdntHBPnApxbTebB9N5KoHZd3VMkk3G2cTY563nu5w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php $__env->stopPush(); ?>
    
    <?php if (isset($component)) { $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804)): ?>
<?php $component = $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804; ?>
<?php unset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804); ?>
<?php endif; ?>
    
    <div class="breadcrumb-container">
        <div class="container">
            <nav class="breadcrumb">
                <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">Home</a>
                <a class="breadcrumb-item" href="<?php echo e(url('/news')); ?>">Berita</a>
                <span class="breadcrumb-item active"><?php echo e($gallery->title); ?></span>
            </nav>
        </div>
    </div>

    <div class="container">
        <div class="news-container galery-container my-5">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <?php if (isset($component)) { $__componentOriginal5656a25c0f87b6e6d4ce4d5a6308e0c08a8b3789 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppWidgetCategories::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-widget-categories'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppWidgetCategories::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5656a25c0f87b6e6d4ce4d5a6308e0c08a8b3789)): ?>
<?php $component = $__componentOriginal5656a25c0f87b6e6d4ce4d5a6308e0c08a8b3789; ?>
<?php unset($__componentOriginal5656a25c0f87b6e6d4ce4d5a6308e0c08a8b3789); ?>
<?php endif; ?>
                </div>
                <div class="col-md-9 mb-3">
                    <div class="news-headline pb-3">
                        <h4><?php echo e($gallery->title); ?></h3>
                        <small class="text-dark">
                            <i class="bi bi-clock"></i> <?php echo e(Helpers::hari($gallery->created_at)); ?>, <?php echo e(Helpers::tanggal($gallery->created_at)); ?>

                        </small>
                    </div>
                    <div class="news-text">
                        <?php echo $gallery->text; ?>

                    </div>
                    <div class="moreNews">
                        <div class="row" id="images">
                            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 mb-3">
                                    <div class="news-item news-item-right">
                                        <img src="<?php echo e($item->photo); ?>" alt="Photos" width="100%"/>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69)): ?>
<?php $component = $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69; ?>
<?php unset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69); ?>
<?php endif; ?>
    
    <?php $__env->startPush('script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/viewerjs/1.10.4/viewer.min.js" integrity="sha512-2HLzgJH7ZNywnEDB1HqijieFxszStt3QXS8Qk9m/VMUV/asMWlz9PmibHsvWIz9rtKOOr28z8zu1iJ3pf/TTHQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script>
            $(document).ready(function(){
                const gallery = new Viewer(document.getElementById('images'));
            });
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Project\Laravel\ikapeksi\resources\views/galleryDetail.blade.php ENDPATH**/ ?>