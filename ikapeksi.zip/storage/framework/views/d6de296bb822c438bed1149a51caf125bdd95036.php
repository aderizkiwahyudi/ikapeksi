<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => 'Administrator'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="wrapper" id="wrapper">

        <?php $__env->startPush('style'); ?>
        <?php $__env->stopPush(); ?>

        <?php if (isset($component)) { $__componentOriginal548fe59e8e4d424287091d005d0da84f5245ee0c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal548fe59e8e4d424287091d005d0da84f5245ee0c)): ?>
<?php $component = $__componentOriginal548fe59e8e4d424287091d005d0da84f5245ee0c; ?>
<?php unset($__componentOriginal548fe59e8e4d424287091d005d0da84f5245ee0c); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal3521a1fa11002ac0abd148abefb6a68539feeea0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminSidebar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3521a1fa11002ac0abd148abefb6a68539feeea0)): ?>
<?php $component = $__componentOriginal3521a1fa11002ac0abd148abefb6a68539feeea0; ?>
<?php unset($__componentOriginal3521a1fa11002ac0abd148abefb6a68539feeea0); ?>
<?php endif; ?>

        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Pengaturan Web</h1>
                            <p>Perbarui informasi website</p>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('administrator')); ?>">Home</a></li>
                                <li class="breadcrumb-item active">Pengaturan Web</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
      
            <form method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <section class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        <strong>Gagal! </strong>
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($item); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul> 
                                    </div>
                                <?php endif; ?>

                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        <strong>Berhasil! </strong> <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <div class="row align-items-center">
                                            <div class="col-md-12">
                                                <div class="bg-white shadow-sm border mb-3">
                                                    <div class="widget-header p-3 border-bottom">
                                                        <strong>Pengaturan Website</strong>
                                                    </div>
                                                    <div class="p-3">
                                                        <div class="form-group">
                                                            <input type="text" placeholder="Enter Website Name" class="form-control" value="<?php echo e($web->name); ?>" name="name" id="name"/>
                                                        </div>
                                                        <div class="form-group">
                                                            <input type="file" class="form-control" name="logo" id="logo"/>
                                                            <div class="my-2">
                                                                <img src="<?php echo e($web->logo); ?>" alt="Logo" width="150px"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <textarea type="text" placeholder="Enter About Website" class="form-control" name="about" id="about"><?php echo e($web->about); ?></textarea>
                                                        </div>
                                                        <div class="form-group">
                                                            <input type="email" placeholder="Enter Email Website" class="form-control" value="<?php echo e($web->email); ?>" name="email" id="email"/>
                                                        </div>
                                                        <div class="form-group">
                                                            <input type="text" placeholder="Enter Instagram" class="form-control" value="<?php echo e($web->instagram); ?>" name="instagram" id="instagram"/>
                                                        </div>
                                                        <div class="form-group">
                                                            <input type="text" placeholder="Enter Facebook" class="form-control" value="<?php echo e($web->facebook); ?>" name="facebook" id="facebook"/>
                                                        </div>
                                                        <div class="form-group">
                                                            <input type="text" placeholder="Enter Twitter" class="form-control" value="<?php echo e($web->twitter); ?>" name="twitter" id="twitter"/>
                                                        </div>
                                                        <div class="form-group">
                                                            <input type="text" placeholder="Enter Phone Number" class="form-control" value="<?php echo e($web->phone); ?>" name="phone" id="phone"/>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="Photo">Foto Ketua Umum</label>
                                                            <input type="file" class="form-control" name="photo" id="photo"/>
                                                            <div class="my-2">
                                                                <img src="<?php echo e($web->photo); ?>" alt="Logo" width="150px"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="Sambutan">Sambutan Ketua Umum</label>
                                                            <textarea name="sambutan" class="editor"><?php echo e($web->sambutan); ?></textarea>
                                                        </div>
                                                        <button type="submit" class="btn btn-primary">SIMPAN</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </form>

        </div>

        <?php if (isset($component)) { $__componentOriginal0af80189ee9d18748f45cc907e25d7b5a0980777 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppAdminFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-admin-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppAdminFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0af80189ee9d18748f45cc907e25d7b5a0980777)): ?>
<?php $component = $__componentOriginal0af80189ee9d18748f45cc907e25d7b5a0980777; ?>
<?php unset($__componentOriginal0af80189ee9d18748f45cc907e25d7b5a0980777); ?>
<?php endif; ?>

        <?php $__env->startPush('script'); ?>
            <script src="<?php echo e(asset('plugin/ckeditor/build/ckeditor.js')); ?>"></script>
            <script src="<?php echo e(asset('plugin/ckfinder/ckfinder.js')); ?>"></script>
            <script>
                $(document).ready( function () {
                    ClassicEditor
                    .create( document.querySelector( '.editor' ), {
                        licenseKey: '',
                        ckfinder: {
                            uploadUrl: '<?php echo asset("plugin/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json"); ?>',
                            options: {
                                resourceType: 'Images'
                            }
                        },
                    })
                    .then( editor => {
                        window.editor = editor;
                    })
                    .catch( error => {
                        console.error( 'Oops, something went wrong!' );
                        console.error( 'Please, report the following error on https://github.com/ckeditor/ckeditor5/issues with the build id and the error stack trace:' );
                        console.warn( 'Build id: nyny6d5pm98w-f9z6zbpoy7ms' );
                        console.error( error );
                    });
                });
            </script>
        <?php $__env->stopPush(); ?>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Project\Laravel\ikapeksi\resources\views/administrator/pengaturan/web/index.blade.php ENDPATH**/ ?>