<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => ''.e($news->title).''] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startPush('meta'); ?>
            <meta property="og:title" content="<?php echo e($news->title); ?>">
            <meta property="og:type" content="article"/>
            <meta property="og:image" content="<?php echo e($news->thumbnail); ?>">
            <meta property="og:url" content="<?php echo e(url('news/' . $news->slug)); ?>">
            <meta name="twitter:card" content="summary_large_image">
    <?php $__env->stopPush(); ?>
    
    <?php if (isset($component)) { $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppHeader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804)): ?>
<?php $component = $__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804; ?>
<?php unset($__componentOriginal19004a47437f104404f1f701a8f79ec8feb96804); ?>
<?php endif; ?>
    
    <div class="breadcrumb-container">
        <div class="container">
            <nav class="breadcrumb">
                <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">Home</a>
                <a class="breadcrumb-item" href="<?php echo e(url('/news')); ?>">Berita</a>
                <span class="breadcrumb-item active"><?php echo e($news->title); ?></span>
            </nav>
        </div>
    </div>

    <div class="container">
        <div class="news-container my-5">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <?php if (isset($component)) { $__componentOriginal5656a25c0f87b6e6d4ce4d5a6308e0c08a8b3789 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppWidgetCategories::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-widget-categories'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppWidgetCategories::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5656a25c0f87b6e6d4ce4d5a6308e0c08a8b3789)): ?>
<?php $component = $__componentOriginal5656a25c0f87b6e6d4ce4d5a6308e0c08a8b3789; ?>
<?php unset($__componentOriginal5656a25c0f87b6e6d4ce4d5a6308e0c08a8b3789); ?>
<?php endif; ?>
                </div>
                <div class="col-md-9 mb-3">
                    <div class="news-headline pb-3">
                        <h4><?php echo e($news->title); ?></h3>
                        <small class="text-dark">
                            <i class="bi bi-clock"></i> <?php echo e(Helpers::hari($news->created_at)); ?>, <?php echo e(Helpers::tanggal($news->created_at)); ?>

                        </small>
                    </div>
                    <img src="<?php echo e($news->thumbnail); ?>" alt="<?php echo e($news->title); ?>" width="100%"/>
                    <div class="news-text pt-3">
                        <?php echo $news->text; ?>

                    </div>
                    <div class="share py-3">
                        <div class="d-flex align-items-center" id="share-sossial-buttons">
                            <div class="me-2">
                                Share
                            </div>
                            <!-- Untuk Email -->
                            <a class="btn btn-share-mail" href="mailto:?Subject=<?php echo e($news->title); ?>&Body=<?php echo $news->text; ?>">
                                <i class="bi bi-envelope-fill"></i>
                            </a>
                            <!-- Untuk Facebook -->
                            <a class="btn btn-share-facebook"  href="http://www.facebook.com/sharer.php?u=<?php echo e(url('news/' . $news->slug)); ?>" target="_blank">
                                <i class="bi bi-facebook"></i>
                            </a>
                            <!-- Untuk Google+ -->
                            <a class="btn btn-share-gplus" href="https://plus.google.com/share?url=<?php echo e(url('news/' . $news->slug)); ?>" target="_blank">
                                <i class="bi bi-google"></i>
                            </a>
                            <!-- Untuk Twitter -->
                            <a class="btn btn-share-twitter" href="https://twitter.com/share?url=<?php echo e(url('news/' . $news->slug)); ?>&text=<?php echo e($news->title); ?>" target="_blank">
                                <i class="bi bi-twitter"></i>
                            </a>
                        </div>
                    </div>
                    <div class="moreNews">
                        <h5>Berita Lainnya :</h5>
                        <div class="row">
                            <div class="row">
                                <?php $__currentLoopData = $newsMore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="news-item news-item-right">
                                            <div class="thumbnail" style="background-image: url('<?php echo e($item->thumbnail); ?>');"></div>
                                            <div class="news-item-body">
                                                <div class="date"><?php echo e(Helpers::hari($item->created_at)); ?>, <?php echo e(Helpers::tanggal($item->created_at)); ?></div>
                                                <h2><a href="<?php echo e(url('news/' . $item->slug)); ?>"><?php echo e($item->title); ?></a></h2>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppFooter::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69)): ?>
<?php $component = $__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69; ?>
<?php unset($__componentOriginal45d2dce3b6e23e3648270c5a8b7bfdd46e45fa69); ?>
<?php endif; ?>
    
    <?php $__env->startPush('script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script>
            $(document).ready(function(){
                
            });
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Project\Laravel\ikapeksi\resources\views/newsDetail.blade.php ENDPATH**/ ?>